import bcrypt
import pyotp

# Receber input do usuário
username = input("Usuário: ")
password = input("Senha: ")

# Gerar hash da senha
hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

# Gerar chave secreta 2FA
two_fa_secret = pyotp.random_base32()

# Imprimir o resultado
print("\nUsuário gerado:")
print(f'"{username}": {{')
print(f'  "password": "{hashed_password}",')
print(f'  "2fa_secret": "{two_fa_secret}"')
print("}")
