################################
## IMPORTAÇÕES DE BIBLIOTECAS ##
################################
import os
import uuid
import json
import pyotp
import bcrypt
import secrets
import logging
from functools import wraps
from datetime import timedelta
from flask_limiter import Limiter
from flask_talisman import Talisman
from logging.handlers import RotatingFileHandler
from flask_limiter.util import get_remote_address
from flask_jwt_extended.exceptions import JWTDecodeError
from flask import Flask, request, redirect, url_for, session, flash, render_template, make_response
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, set_access_cookies


###########################
## CONFIGURAÇÃO DO FLASK ##
###########################
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32))
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', secrets.token_hex(32))
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=30)
app.config['JWT_COOKIE_SECURE'] = True
app.config['JWT_COOKIE_CSRF_PROTECT'] = False
app.config['JWT_TOKEN_LOCATION'] = ['cookies']
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

#############################
## CONFIGURAÇÃO DO LOGGING ##
#############################
LOG_FILE = 'logs/app.log'
if not os.path.exists('logs'):
    os.makedirs('logs')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        ######################################################
        ## SALVA LOGS EM UM ARQUIVO E FAZ ROTINA DE LIMPEZA ##
        ######################################################
        RotatingFileHandler(LOG_FILE, maxBytes=1000000, backupCount=5),  
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Inicializa extensões de segurança
jwt = JWTManager(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"])
talisman = Talisman(
    app,
    force_https=True,
    strict_transport_security=True,
    session_cookie_secure=True,
    content_security_policy={
        'default-src': "'self'",
        'script-src': "'self' 'unsafe-inline'",
        'style-src': "'self' 'unsafe-inline'",
        'font-src': "'self'",
    },
    x_content_type_options='nosniff',
    referrer_policy='strict-origin-when-cross-origin'
)

# Caminho para o banco de dados JSON
DATA_DIR = "data"
USERS_PATH = os.path.join(DATA_DIR, "users.json")
DB_PATH = os.path.join(DATA_DIR, "db.json")
UPLOAD_FOLDER = 'uploads'

# Garante que as pastas necessárias existam
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Funções utilitárias
def load_users():
    if not os.path.exists(USERS_PATH):
        return {}
    
    with open(USERS_PATH, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}

def save_users(users):
    with open(USERS_PATH, "w") as f:
        json.dump(users, f, indent=4)

def load_db():
    if not os.path.exists(DB_PATH):
        return {"passwords": [], "notes": []}
    
    with open(DB_PATH, "r") as f:
        try:
            data = json.load(f)
            return {"passwords": data.get("passwords", []), "notes": data.get("notes", [])}
        except json.JSONDecodeError:
            return {"passwords": [], "notes": []}

def save_db(data):
    with open(DB_PATH, "w") as f:
        json.dump(data, f, indent=4)

def hash_passworde(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(hashed_password, input_password):
    return bcrypt.checkpw(input_password.encode('utf-8'), hashed_password.encode('utf-8'))

def allowed_file(filename):
    return True

def get_mac_address():
    mac = uuid.getnode()
    return ':'.join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))

# Decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Rotas
@app.before_request
def enforce_https():
    if not request.is_secure:
        url = request.url.replace('http://', 'https://', 1)
        return redirect(url, code=301)
@app.after_request
def add_security_headers(response):
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

@app.errorhandler(JWTDecodeError)
def handle_invalid_token(e):
    # Limpa o cookie inválido
    response = make_response(redirect(url_for('login')))
    response.delete_cookie('access_token_cookie')
    return response

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("10 per minute")
def login():
    session.clear()

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        users = load_users()

        user = users.get(username)
        if user and verify_password(user['password'], password):
            if user.get('2fa_secret'):
                session['2fa_username'] = username
                logger.info(f"Login iniciado (2FA): Usuário={username}, IP={request.remote_addr}, MAC={get_mac_address()}")
                return redirect(url_for('verify_2fa'))
            else:
                access_token = create_access_token(identity=username)
                response = make_response(redirect(url_for('dashboard')))
                set_access_cookies(response, access_token)
                session['logged_in'] = True
                logger.info(f"Login bem-sucedido: Usuário={username}, IP={request.remote_addr}, MAC={get_mac_address()}")
                return response
        else:
            logger.warning(f"Tentativa de login falhou: Usuário={username}, IP={request.remote_addr}, MAC={get_mac_address()}")
            flash('Usuário ou senha inválidos', 'error')

    return render_template('login.html')

@app.route('/logout')
def logout():
    username = session.get('logged_in_user', 'Desconhecido')
    session.clear()
    response = make_response(redirect(url_for('login')))
    response.delete_cookie('access_token_cookie')
    logger.info(f"Logout: Usuário={username}, IP={request.remote_addr}, MAC={get_mac_address()}")
    return response

def verify_2fa_code(secret, code):
    try:
        totp = pyotp.TOTP(secret)
    except Exception as e:
        print(e)

    return totp.verify(code)

@app.route('/verify-2fa', methods=['GET', 'POST'])
@limiter.limit("10 per minute")
def verify_2fa():
    if '2fa_username' not in session:
        flash('Por favor, faça login primeiro.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        code = request.form.get('code')
        username = session.get('2fa_username')
        users = load_users()
        user = users.get(username)

        if user and verify_2fa_code(user['2fa_secret'], code):
            access_token = create_access_token(identity=username)
            response = make_response(redirect(url_for('dashboard')))
            set_access_cookies(response, access_token)
            session['logged_in'] = True
            session.pop('2fa_username', None)
            logger.info(f"2FA validado: Usuário={username}, IP={request.remote_addr}, MAC={get_mac_address()}")
            return response
        else:
            flash('Código 2FA inválido', 'error')

    return render_template('verify_2fa.html')

@app.route('/')
@login_required
@jwt_required()
def dashboard():
    current_user = get_jwt_identity()  # Obtém o usuário autenticado
    db = load_db()
    passwords = db.get("passwords", [])
    return render_template('dashboard.html', passwords=passwords, active_section='passwords', current_user=current_user)

@app.route('/secure-notes')
@login_required
@jwt_required()
def secure_notes():
    db = load_db()
    notes = db.get("notes", [])
    return render_template('dashboard.html', active_section='secure-notes', notes=notes)

@app.route('/notes/add', methods=['POST'])
@login_required
@jwt_required()
def add_notes():
    current_user = get_jwt_identity()
    data = request.form
    db = load_db()
    new_id = max([p['id'] for p in db['note']], default=0) + 1
    new_password = {
        'id': new_id,
        'machine_name': data['machine_name'],
        'ip': data['ip'],
        'login': data['login'],
        'password': data['password']
    }
    db['passwords'].append(new_password)
    save_db(db)
    logger.info(f"Senha adicionada: Usuário={current_user}, IP={request.remote_addr}, MAC={get_mac_address()}, Detalhes={new_password}")
    flash('Senha adicionada com sucesso!', 'success')
    return redirect(url_for('dashboard'))


@app.errorhandler(422)
def page_not_found(e):
    return redirect(url_for('login'))

@app.errorhandler(401)
def page_not_found(e):
    return render_template('401.html'), 401

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(429)
def page_not_found(e):
    return render_template('429.html'), 429

@app.route('/files')
@login_required
@jwt_required()
def files():
    return render_template('dashboard.html', active_section='files')

@app.route('/upload-file', methods=['POST'])
@login_required
@jwt_required()
def upload_file():
    if 'file' not in request.files:
        flash('Nenhum arquivo foi enviado!', 'error')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('Nenhum arquivo selecionado!', 'error')
        return redirect(request.url)

    if file and allowed_file(file.filename):
        filename = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filename)
        flash('Arquivo enviado com sucesso!', 'success')
        return redirect(url_for('files'))

    flash('Formato de arquivo inválido!', 'error')
    return redirect(request.url)

@app.route('/password/add', methods=['POST'])
@login_required
@jwt_required()
def add_password():
    current_user = get_jwt_identity()  # Obtém o usuário autenticado
    data = request.form
    db = load_db()
    new_id = max([p['id'] for p in db['passwords']], default=0) + 1
    
    new_password = {
        'id': new_id,
        'machine_name': data['machine_name'],
        'ip': data['ip'],
        'login': data['login'],
        'password': data['password'],
        'added_by': current_user  # Registra quem adicionou a senha
    }
    
    db['passwords'].append(new_password)
    save_db(db)
    flash('Senha adicionada com sucesso!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/password/edit/<int:id>', methods=['POST'])
@login_required
@jwt_required()
def edit_password(id):
    current_user = get_jwt_identity()  # Obtém o usuário autenticado
    data = request.form
    db = load_db()
    
    for password in db['passwords']:
        if password['id'] == id:
            password.update({
                'machine_name': data['machine_name'],
                'ip': data['ip'],
                'login': data['login'],
                'password': data['password'],
                'last_modified_by': current_user  # Registra quem editou a senha
            })
            save_db(db)
            flash('Senha editada com sucesso!', 'success')
            break
    
    return redirect(url_for('dashboard'))

@app.route('/password/delete/<int:id>', methods=['POST'])
@login_required
@jwt_required()
def delete_password(id):
    current_user = get_jwt_identity()  # Obtém o usuário autenticado
    db = load_db()
    
    deleted_password = next((p for p in db['passwords'] if p['id'] == id), None)
    if deleted_password:
        db['passwords'] = [p for p in db['passwords'] if p['id'] != id]
        save_db(db)
        logger.info(f"Senha excluída por {current_user}: {deleted_password}")  # Registra quem excluiu a senha
        flash('Senha excluída com sucesso!', 'success')
    
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    #openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes
    app.run(debug=True, host='0.0.0.0', port=5000, ssl_context=('cert.pem', 'key.pem'))