// main.js
document.addEventListener('DOMContentLoaded', function() {
  });
  document.addEventListener('DOMContentLoaded', function() {

    // --- Senhas: Exibe senha real ao passar o mouse ---
    document.querySelectorAll('.password-mask').forEach(function(elem) {
      elem.addEventListener('mouseenter', function() {
        this.textContent = this.getAttribute('data-password');
      });
      elem.addEventListener('mouseleave', function() {
        this.textContent = '-------';
      });
    });
  
    // --- Código relacionado à seção de Senhas ---
    const addPasswordBtn = document.getElementById('addPasswordBtn');
    if (addPasswordBtn) {
      addPasswordBtn.addEventListener('click', function() {
        // Limpar campos para nova senha
        const idElem = document.getElementById('password-id');
        const machineElem = document.getElementById('password-machine_name');
        const ipElem = document.getElementById('password-ip');
        const loginElem = document.getElementById('password-login');
        const passElem = document.getElementById('password-password');
        if (idElem && machineElem && ipElem && loginElem && passElem) {
          idElem.value = '';
          machineElem.value = '';
          ipElem.value = '';
          loginElem.value = '';
          passElem.value = '';
        }
        const passwordModal = document.getElementById('passwordModal');
        const passwordModalTitle = document.getElementById('passwordModalTitle');
        const passwordForm = document.getElementById('passwordForm');
        if (passwordModal && passwordModalTitle && passwordForm) {
          passwordModalTitle.textContent = 'Adicionar Senha';
          passwordForm.action = '/password/add';
          passwordModal.style.display = 'block';
        }
      });
    }
  
    const editBtns = document.querySelectorAll('.edit-btn');
    if(editBtns) {
      editBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          const machine = this.getAttribute('data-machine');
          const ip = this.getAttribute('data-ip');
          const login = this.getAttribute('data-login');
          const pwd = this.getAttribute('data-password');
  
          const idElem = document.getElementById('password-id');
          const machineElem = document.getElementById('password-machine_name');
          const ipElem = document.getElementById('password-ip');
          const loginElem = document.getElementById('password-login');
          const passElem = document.getElementById('password-password');
          if (idElem && machineElem && ipElem && loginElem && passElem) {
            idElem.value = id;
            machineElem.value = machine;
            ipElem.value = ip;
            loginElem.value = login;
            passElem.value = pwd;
          }
  
          const passwordModal = document.getElementById('passwordModal');
          const passwordModalTitle = document.getElementById('passwordModalTitle');
          const passwordForm = document.getElementById('passwordForm');
          if (passwordModal && passwordModalTitle && passwordForm) {
            passwordModalTitle.textContent = 'Editar Senha';
            passwordForm.action = `/password/edit/${id}`;
            passwordModal.style.display = 'block';
          }
        });
      });
    }
  
    const deleteBtns = document.querySelectorAll('.delete-btn');
    if(deleteBtns) {
      deleteBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          if (confirm('Tem certeza que deseja excluir esta senha?')) {
            fetch(`/password/delete/${id}`, { method: 'POST' })
              .then(() => window.location.reload());
          }
        });
      });
    }
  
    // Registrar evento para fechar o modal de Senhas, se existir
    const passwordModalClose = document.getElementById('passwordModalClose');
    const passwordModal = document.getElementById('passwordModal'); // reobtém para segurança
    if (passwordModalClose && passwordModal) {
      passwordModalClose.addEventListener('click', function() {
        passwordModal.style.display = 'none';
      });
    }
  
    // --- Código relacionado à seção de Anotações ---
    const addNoteBtn = document.getElementById('addNoteBtn');
    if (addNoteBtn) {
      addNoteBtn.addEventListener('click', function() {
        const noteIdElem = document.getElementById('note-id');
        const noteTitleElem = document.getElementById('note-title');
        const noteContentElem = document.getElementById('note-content');
        if (noteIdElem && noteTitleElem && noteContentElem) {
          noteIdElem.value = '';
          noteTitleElem.value = '';
          noteContentElem.value = '';
        } else {
        }
        const noteModal = document.getElementById('noteModal');
        const noteModalTitle = document.getElementById('noteModalTitle');
        const noteForm = document.getElementById('noteForm');
        if (noteModal && noteModalTitle && noteForm) {
          noteModalTitle.textContent = 'Adicionar Anotação';
          noteForm.action = '/notes/add';
          noteModal.style.display = 'block';
        }
      });
    } 
  
    const editNoteBtns = document.querySelectorAll('.edit-note-btn');
    if(editNoteBtns) {
      editNoteBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          const title = this.getAttribute('data-title');
          const content = this.getAttribute('data-content');
  
          const noteIdElem = document.getElementById('note-id');
          const noteTitleElem = document.getElementById('note-title');
          const noteContentElem = document.getElementById('note-content');
          if (noteIdElem && noteTitleElem && noteContentElem) {
            noteIdElem.value = id;
            noteTitleElem.value = title;
            noteContentElem.value = content;
          }
  
          const noteModal = document.getElementById('noteModal');
          const noteModalTitle = document.getElementById('noteModalTitle');
          const noteForm = document.getElementById('noteForm');
          if (noteModal && noteModalTitle && noteForm) {
            noteModalTitle.textContent = 'Editar Anotação';
            noteForm.action = `/notes/edit/${id}`;
            noteModal.style.display = 'block';
          }
        });
      });
    }
  
    const noteModalClose = document.getElementById('noteModalClose');
    const noteModal = document.getElementById('noteModal'); // reobtém
    if (noteModalClose && noteModal) {
      noteModalClose.addEventListener('click', function() {
        noteModal.style.display = 'none';
      });
    }
  
    const deleteNoteBtns = document.querySelectorAll('.delete-note-btn');
    if(deleteNoteBtns) {
      deleteNoteBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          const noteDeleteModal = document.getElementById('noteDeleteModal');
          const noteDeleteForm = document.getElementById('noteDeleteForm');
          if (noteDeleteModal && noteDeleteForm) {
            noteDeleteForm.action = `/notes/delete/${id}`;
            noteDeleteModal.style.display = 'block';
          }
        });
      });
    }
  
    const noteDeleteClose = document.getElementById('noteDeleteClose');
    if(noteDeleteClose) {
      noteDeleteClose.addEventListener('click', function() {
        const noteDeleteModal = document.getElementById('noteDeleteModal');
        if(noteDeleteModal) {
          noteDeleteModal.style.display = 'none';
        }
      });
    }
  
    const cancelNoteDelete = document.getElementById('cancelNoteDelete');
    if(cancelNoteDelete) {
      cancelNoteDelete.addEventListener('click', function() {
        const noteDeleteModal = document.getElementById('noteDeleteModal');
        if(noteDeleteModal) {
          noteDeleteModal.style.display = 'none';
        }
      });
    }
  
    // Fecha os modais ao clicar fora do conteúdo
    window.addEventListener('click', function(event) {
      const passwordModal = document.getElementById('passwordModal');
      const noteModal = document.getElementById('noteModal');
      const noteDeleteModal = document.getElementById('noteDeleteModal');
      if (passwordModal && event.target == passwordModal) {
        passwordModal.style.display = 'none';
      }
      if (noteModal && event.target == noteModal) {
        noteModal.style.display = 'none';
      }
      if (noteDeleteModal && event.target == noteDeleteModal) {
        noteDeleteModal.style.display = 'none';
      }
    });
  });
  
  document.addEventListener('DOMContentLoaded', function() {
      // Manipulação de formulários e interações adicionais podem ser inseridas aqui
  
      // Exemplo de ação para o upload de arquivos (se necessário)
      const fileInput = document.querySelector("input[type='file']");
      if (fileInput) {
          fileInput.addEventListener('change', function(e) {
              const fileName = e.target.files[0].name;
              console.log('Arquivo selecionado:', fileName);
          });
      }
  });  
  
  // Fecha o modal ao pressionar a tecla ESC
  window.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
      const passwordModal = document.getElementById('passwordModal');
      const noteModal = document.getElementById('noteModal');
      const noteDeleteModal = document.getElementById('noteDeleteModal');
      if (passwordModal) passwordModal.style.display = 'none';
      if (noteModal) noteModal.style.display = 'none';
      if (noteDeleteModal) noteDeleteModal.style.display = 'none';
    }
  });
  
  function copyPasswordToClipboard(event, el) {
    event.preventDefault();
    const password = el.getAttribute('data-password');
    const textArea = document.createElement('textarea');
    textArea.value = password;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    textArea.remove();
  }